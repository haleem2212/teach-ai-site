/* Subject lesson logic with voice interaction */
window.addEventListener('DOMContentLoaded', () => {
    const userJSON = localStorage.getItem('user');
    if (!userJSON) {
        window.location.href = 'signup.html';
        return;
    }
    const user = JSON.parse(userJSON);
    const subject = getSubjectFromPath();
    // Predefined content per subject and level
    const content = {
        math: {
            beginner: {
                intro: `Hi ${user.name}, welcome to Maths for beginners. We will start with basic addition such as 2 + 3 = 5.`,
                help: 'Addition combines numbers to find the sum. Try adding small numbers together.',
                example: 'Example: 4 + 1 equals 5. Now you try adding 6 and 2.'
            },
            intermediate: {
                intro: `Hello ${user.name}, this is Maths intermediate. We will explore multiplication like 3 × 4 = 12.`,
                help: 'Multiplication is repeated addition. Multiply 5 by 3 by adding 5 three times.',
                example: 'Example: 5 × 3 equals 15. Try 6 × 4 next.'
            },
            experienced: {
                intro: `Welcome ${user.name} to advanced Maths. Today, let’s tackle algebra: solve x + 3 = 7. x equals 4.`,
                help: 'Algebra uses symbols to represent numbers. Isolate the variable to find its value.',
                example: 'Example: Solve 2x = 10. x equals 5.'
            }
        },
        english: {
            beginner: {
                intro: `Hi ${user.name}, welcome to English for beginners. Let’s start with simple sentences like “The cat sits.”`,
                help: 'A sentence has a subject and a verb. Keep them short and clear.',
                example: 'Example: “I like apples.” Try forming your own sentence.'
            },
            intermediate: {
                intro: `Hello ${user.name}, this is English intermediate. We will learn about adjectives and adverbs.`,
                help: 'Adjectives describe nouns; adverbs describe verbs. They add detail to sentences.',
                example: 'Example: “The quick brown fox jumps swiftly.” Notice how adjectives and adverb are used.'
            },
            experienced: {
                intro: `Welcome ${user.name} to advanced English. Today we explore essay structure and rhetorical devices.`,
                help: 'An essay has an introduction, body and conclusion. Use devices like metaphors to enhance writing.',
                example: 'Example: Craft a paragraph comparing freedom to a bird in flight.'
            }
        },
        science: {
            beginner: {
                intro: `Hi ${user.name}, welcome to Science beginners. Let’s learn about the water cycle: evaporation, condensation, precipitation.`,
                help: 'The water cycle describes how water moves through the environment.',
                example: 'Example: Water evaporates from oceans, forms clouds and falls as rain.'
            },
            intermediate: {
                intro: `Hello ${user.name}, this is Science intermediate. We will discuss gravity and Newton’s laws.`,
                help: 'Gravity is the force pulling objects toward each other. Newton’s laws describe motion.',
                example: 'Example: A ball thrown upwards slows down due to gravity and then falls back.'
            },
            experienced: {
                intro: `Welcome ${user.name} to advanced Science. Today we examine cell biology and DNA replication.`,
                help: 'Cells are the basic units of life. DNA replication ensures genetic information is copied accurately.',
                example: 'Example: In mitosis, a cell divides to produce two identical daughter cells.'
            }
        },
        languages: {
            beginner: {
                intro: `Hi ${user.name}, welcome to Languages beginners. Let’s learn basic greetings in multiple languages.`,
                help: 'Start with hello, thank you and goodbye in your chosen language.',
                example: 'Example: In Spanish, “Hola” means hello. Try saying hello in French: “Bonjour”.'
            },
            intermediate: {
                intro: `Hello ${user.name}, this is Languages intermediate. We will practice common phrases and grammar.`,
                help: 'Construct simple sentences and focus on verb conjugation.',
                example: 'Example: In German, “Ich spiele Fussball” means I play football.'
            },
            experienced: {
                intro: `Welcome ${user.name} to advanced Languages. Today we work on conversation and comprehension.`,
                help: 'Listen to native speakers and practice conversing. Expand your vocabulary.',
                example: 'Example: In Mandarin, listen to a short story and try to summarise it.'
            }
        },
        coding: {
            beginner: {
                intro: `Hi ${user.name}, welcome to Coding beginners. We will start with printing messages in Python: print("Hello world").`,
                help: 'Programming instructions tell the computer what to do. Start with simple output.',
                example: 'Example: In JavaScript, you can write console.log("Hello AI"); to print a message.'
            },
            intermediate: {
                intro: `Hello ${user.name}, this is Coding intermediate. We will learn about loops and conditions.`,
                help: 'Loops repeat a block of code; conditions run code only if a test is true.',
                example: 'Example: In Python: for i in range(3): print(i). This prints 0, 1, 2.'
            },
            experienced: {
                intro: `Welcome ${user.name} to advanced Coding. Today we explore algorithms and data structures like trees and sorting.`,
                help: 'Algorithms are procedures for solving problems; data structures organise data efficiently.',
                example: 'Example: Implement a binary search to find a value in a sorted list.'
            }
        }
    };
    /*
     * Determine the actual lesson level based on the user’s subscription plan
     * and their chosen level.  Basic subscribers are capped at beginner,
     * standard subscribers at intermediate, and premium subscribers receive
     * full experienced content.  Levels are ranked as integers for
     * comparison.
     */
    const levelRanks = { beginner: 0, intermediate: 1, experienced: 2 };
    const planRanks = { basic: 0, standard: 1, premium: 2 };
    const userPlanRank = planRanks[user.plan] ?? 0;
    const userLevelRank = levelRanks[user.level] ?? 0;
    const finalLevelRank = Math.min(userLevelRank, userPlanRank);
    const levelFromRank = Object.keys(levelRanks).find(l => levelRanks[l] === finalLevelRank) || 'beginner';
    const userLevel = levelFromRank;

    const subjectData = (content[subject] && content[subject][userLevel]) || null;
    const introEl = document.getElementById('intro');
    const contentEl = document.getElementById('content');
    const responseEl = document.getElementById('response');
    const micBtn = document.getElementById('micBtn');
    const helpBtn = document.getElementById('helpBtn');
    const exampleBtn = document.getElementById('exampleBtn');
    // Determine the age group for a personalised greeting
    function getAgeGroup(age) {
        const a = Number(age);
        if (!a) return 'adult';
        if (a < 12) return 'child';
        if (a < 18) return 'teen';
        return 'adult';
    }
    const ageGroup = getAgeGroup(user.age);
    // Set intro and speak.  Prepend a friendly greeting based on age group.
    if (subjectData) {
        let intro = subjectData.intro;
        if (ageGroup === 'child') {
            intro = `Hey there! ` + intro;
        } else if (ageGroup === 'teen') {
            intro = `Hi, let’s dive in. ` + intro;
        } else {
            intro = `Welcome. ` + intro;
        }
        introEl.textContent = intro;
        speak(intro, user.language);
        contentEl.textContent = intro;
        // If the user level had to be downgraded due to plan restrictions,
        // notify them quietly.
        if (userLevelRank > finalLevelRank) {
            const note = document.createElement('p');
            note.className = 'note';
            note.textContent = `Your chosen level has been adjusted to ${userLevel} based on your current plan (${user.plan}).`;
            contentEl.appendChild(note);
        }
    } else {
        introEl.textContent = 'Welcome to ' + subject + ' lesson.';
    }
    // Event handlers
    micBtn.addEventListener('click', () => {
        startRecognition(user.language).then(result => {
            responseEl.textContent = 'You said: ' + result;
            const lower = result.toLowerCase();
            if (lower.includes('help')) {
                provideHelp(subjectData, user.language);
            } else if (lower.includes('example')) {
                provideExample(subjectData, user.language);
            } else {
                // basic echo response
                const reply = 'I heard you say ' + result + '. Keep practising!';
                speak(reply, user.language);
                responseEl.textContent += '\nAI: ' + reply;
            }
        }).catch(err => {
            responseEl.textContent = 'Error: ' + err;
        });
    });
    helpBtn.addEventListener('click', () => {
        provideHelp(subjectData, user.language);
    });
    exampleBtn.addEventListener('click', () => {
        provideExample(subjectData, user.language);
    });
    /**
     * Helpers
     */
    function getSubjectFromPath() {
        const path = window.location.pathname;
        const file = path.substring(path.lastIndexOf('/') + 1);
        const name = file.split('.')[0];
        return name;
    }
    function speak(text, langCode) {
        const utterance = new SpeechSynthesisUtterance(text);
        const langMap = {
            en: 'en-US',
            es: 'es-ES',
            fr: 'fr-FR',
            de: 'de-DE',
            zh: 'zh-CN',
            ar: 'ar-SA'
        };
        utterance.lang = langMap[langCode] || 'en-US';
        window.speechSynthesis.cancel();
        window.speechSynthesis.speak(utterance);
    }
    function provideHelp(data, lang) {
        if (!data) {
            return;
        }
        speak(data.help, lang);
        contentEl.textContent = data.help;
    }
    function provideExample(data, lang) {
        if (!data) {
            return;
        }
        speak(data.example, lang);
        contentEl.textContent = data.example;
    }
    function startRecognition(langCode) {
        return new Promise((resolve, reject) => {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (!SpeechRecognition) {
                reject('Speech recognition not supported in this browser');
                return;
            }
            const recognition = new SpeechRecognition();
            const langMap = {
                en: 'en-US',
                es: 'es-ES',
                fr: 'fr-FR',
                de: 'de-DE',
                zh: 'zh-CN',
                ar: 'ar-SA'
            };
            recognition.lang = langMap[langCode] || 'en-US';
            recognition.interimResults = false;
            recognition.maxAlternatives = 1;
            recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                resolve(transcript);
            };
            recognition.onerror = (event) => {
                reject(event.error);
            };
            recognition.start();
        });
    }
});