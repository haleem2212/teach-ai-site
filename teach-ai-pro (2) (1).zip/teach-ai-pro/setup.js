/* Setup form handling */
window.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('setupForm');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const details = Object.fromEntries(new FormData(form).entries());
        const userJSON = localStorage.getItem('user');
        let user = {};
        if (userJSON) {
            user = JSON.parse(userJSON);
        }
        user.age = Number(details.age);
        user.language = details.language;
        user.level = details.level;
        localStorage.setItem('user', JSON.stringify(user));
        window.location.href = 'dashboard.html';
    });
});