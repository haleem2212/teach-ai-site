/* Dashboard page logic */
window.addEventListener('DOMContentLoaded', () => {
    const userJSON = localStorage.getItem('user');
    if (!userJSON) {
        window.location.href = 'signup.html';
        return;
    }
    const user = JSON.parse(userJSON);
    if (!user.name || !user.plan || !user.age) {
        window.location.href = 'signup.html';
        return;
    }
    document.getElementById('displayName').textContent = user.name;
    document.getElementById('userName').textContent = user.email || user.name;
    const levelName = user.level ? user.level.charAt(0).toUpperCase() + user.level.slice(1) : '';
    const planName = user.plan ? user.plan.charAt(0).toUpperCase() + user.plan.slice(1) : '';
    document.getElementById('planInfo').textContent = `Plan: ${planName} | Level: ${levelName} | Language: ${user.language}`;
    /*
     * Define available subjects.  The user’s subscription plan limits the highest
     * course level they can access (basic → beginner, standard → intermediate,
     * premium → experienced).  Users can still navigate to any subject page
     * but the content served will be capped according to their plan (see
     * subject.js).  Here we simply render all subjects.
     */
    const subjects = ['math', 'english', 'science', 'languages', 'coding'];
    const container = document.getElementById('subjectsContainer');
    subjects.forEach(subject => {
        const card = document.createElement('div');
        card.className = 'subject';
        const title = subject.charAt(0).toUpperCase() + subject.slice(1);
        // Each subject card links to its lesson page.  All cards are shown
        // regardless of subscription tier; plan restrictions are handled on
        // the lesson pages.
        card.innerHTML = `
            <h3>${title}</h3>
            <p>Interactive ${title} lessons with AI.</p>
            <a href="${subject}.html" class="btn">Open</a>
        `;
        container.appendChild(card);
    });
});